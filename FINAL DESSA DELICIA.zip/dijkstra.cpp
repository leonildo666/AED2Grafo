#include <stdio.h>
#include <iostream>
#include <limits.h>
#define V 6
using namespace std;

int menor_distancia(int distancias[], bool teste[])
{
    int menor = INT_MAX, min_index,ver;
    for (int ver=0; ver<V; ver++)
    {
        if (!teste[ver] && distancias[ver] <=menor)
        {
            menor = distancias[ver];
            min_index = ver;
        }
    }
    return min_index;
}

void dijkstra(int graph[V][V], int F_NODO)
{
    int distancias[V],i;
    bool teste[V];

    for (i=0; i<V; i++)
    {
        distancias[i] = INT_MAX;
        teste[i] = false;
    }
    distancias[F_NODO] = 0;

    for (i=1; i<V-1; i++)
    {
        int u = menor_distancia(distancias, teste);
        teste[u] = true;
        for (int ver = 0; ver < V; ver++)

            if (!teste[ver] && graph[u][ver] && distancias[u] != INT_MAX && distancias[u]+graph[u][ver] < distancias[ver])

                distancias[ver] = distancias[u] + graph[u][ver];
    }

    cout << "Distancias"<< endl;
    for (int i = 0; i < V; i++)
        cout <<i <<" \t\t " <<distancias[i] <<endl;
}

int main()
{
   int GRAFO[V][V] = 
{{0,8,0,18,0,0},
{0,0,20,7,1,0},
{0,0,0,2,0,7},
{0,0,0,0,0,6},
{0,0,0,0,0,0}};

    dijkstra(GRAFO, 0);
    return 0;
}