#coding: utf-8
import numpy as np
from numpy import inf
import os
import subprocess
grafo = False

def up_grafo():
    global grafo
    a = open('grafodijkstra.txt','r') #Altera o grafo a ser carregado, opções na pasta principal
    arq = a.read()
    arq = arq.split('\n')
    for x in range(0,len(arq)):
        arq[x] = arq[x].split(',')

    grafo = np.array(arq) #Transforma o arquivo em uma array do Numpy
    print(grafo)

def add_nodo(lista):
    global grafo

    lista1 = np.array(lista).reshape(1,6) #Conserta o vetor para a inserção na coluna
    lista2 = np.delete(lista,-1, axis=0).reshape(5,1) #Conserta o vetor para a inserção na linha

    grafo = np.append(grafo, lista2, axis=1) #Insere na coluna (Obs: Se inserir a linha primeiro, dá erro)
    grafo = np.append(grafo, lista1, axis=0) #Insere na linha



    print(grafo)

def remove_nodo(nodo):
    global grafo #Remove o nodo ao trocar o valor de cada entrada na matriz
    grafo = np.delete(grafo, nodo, nodo) #Remove a coluna
    grafo = np.delete(grafo, nodo, 0) #Remove a linha
    print(grafo)

def nova_aresta(a,b):
    global grafo #Ánalogo ao remove_nodo
    grafo[a,b] = 1
    grafo[b,a] = 1
    print(grafo)

def mata_aresta(a,b):
    global grafo #Remover uma aresta requer cortar a conexão entre dois nodos
    grafo[a,b] = 0 #ao trocar o valor na matriz
    grafo[b,a] = 0
    print(grafo)

def busca_bts(n):
    global grafo
    fila_controle = [n] #Fila que define a ordem de busca, de acordo com a profundidade
    cursor_fila = 1 
    a = grafo[n].tolist()

    while (len(fila_controle) < len(a)):
        for i in range(0, len(a)):
            if (a[i] != '0') and (i not in fila_controle): #condição para incremento na lista fila_controle, que cria a arvore
                    fila_controle.append(i)
        n = cursor_fila
        cursor_fila += 1
        a = grafo[n].tolist()
    print(fila_controle) 

    print('')

def busca_dfs(n):
    #função que cria a lista de adjacencias
    lista_adjacente = []
    for i in range(0,len(grafo)):
        lista_adjacente.append([])
        for j in range(0, len(grafo[i])):
            if (int(grafo[i][j]) == 0):
                pass
            else:
                lista_adjacente[i].append(j)
    #fim da função

    dfs = [n] #Usa a lista de adjacências para criar a pesquisa
    while (len(dfs)<len(lista_adjacente)):
        backtrack = False #Váriavel que controla o backtracking
        for i in range(0, len(lista_adjacente[n])):
            if lista_adjacente[n][i] not in dfs:
                dfs.append(lista_adjacente[n][i])
                n = lista_adjacente[n][i]
                backtrack = True #Mudar o valor dessa variavel signigfica que foi encontrado um valor
                break #mais profundo
        if (backtrack == False): #Esse condicional é acionado quando se chega ao fundo, ele volta uma casa
            n = lista_adjacente[n][0]
        
    print(dfs)

def alg_prim(n):
    global grafo
    prim = [n] #Vetor que armazena o caminho que o algoritmo vai fazer
    while(len(prim)<len(grafo)): #loop que itera enquanto o grafo não é percorrido
        menor = 9999 
        acerto = 0
        for j in range(0, len(grafo)): #O loop itera em todas as linhas que representam os nodos já visitados
            if (j not in prim): #Não verifica os valores se o nodo não foi visitado
                pass
            else:
                for i in range(0,len(grafo)):
                    if (int(grafo[j][i])<menor) and (int(grafo[j][i]) != 0) and (i not in prim):
                        menor = int(grafo[j][i])
                        acerto = i
        if (acerto not in prim): #Incrementa a lista se o valor for o menor entre todos os nodos já visitados
            prim.append(acerto)
            print(acerto, menor)
    print(prim)

def alg_kruskal():
    global grafo
    lista_vertices = []
    for i in range(0, len(grafo)):
        for j in range(i, len(grafo[i])):
            if (grafo[i][j] != '0'):
                n = [i,j,int(grafo[i][j])]
                lista_vertices.append(n)
    lista_vertices.sort(key=lambda x: x[2])
    print('Lista de Vértices:')
    print('Origem  Destino  Peso')
    for i in range(0, len(lista_vertices)):
        print('{}   -     {}    -    {}'.format(lista_vertices[i][0],lista_vertices[i][1],lista_vertices[i][2]))

    arvore = [lista_vertices[0]]
    ciclo = [lista_vertices[0][0],lista_vertices[0][1]]
    lista_vertices.pop(0)

    while(len(arvore) < len(grafo)-1):
        print(arvore)
        teste0 = lista_vertices[0][0]
        teste1 = lista_vertices[0][1]
        if (teste0 in ciclo) and (teste1 in ciclo):
            lista_vertices.pop(0)
        else:
            ciclo.append(teste0)
            ciclo.append(teste1)
            arvore.append(lista_vertices[0])
            lista_vertices.pop(0)

    print(arvore)

def alg_dijkstra(n):
    proc = subprocess.Popen(["./dijkstra"])
    proc.wait()
        

check = None

while (check != 0):

    check = int(input('LISTA DE OPÇÕES:\n1-CARREGAR GRAFO\n2-INSERIR NODO\n3-REMOVER NODO\n4-INSERIR ARESTA\n5-REMOVER ARESTA\n6-VISUALIZAR GRAFO\n7-IDENTIFICAR FONTES\n8-IDENTIFICAR SUMIDOUROS\n9-GRAU DO VÉRTICE\n10-BUSCA EM LARGURA\n11-BUSCA EM PROFUNDIDADE\n12-PRIM\n13-KRUSKAL\n14-DIJKSTRA\n0-SAIR\n'))

    if check == 1:
        up_grafo()

    if check == 2:
        if grafo == False:
            print('Carregue um grafo primeiro!')
        else:
            teste = int(input('Qual o grau do nodo a ser inserido? '))
            print('Liste as adjacências sem repetí-las')
            nodo = [0 for x in range(0,len(grafo)+1)]
            for i in range(0,teste):
                aresta = int(input(''))
                nodo[aresta] = 1
            add_nodo(nodo)

    if check == 3:
        if grafo == False:
            print('Carregue um grafo primeiro!')
        else:
            print(grafo)
            nodo = int(input('Qual nodo será removido? '))
            remove_nodo(nodo)

    if check == 4:
        print('Quais nodos deseja conectar?')
        a = int(input(''))
        b = int(input(''))
        if(grafo[a,b] and grafo[b,a]) == 0:
            nova_aresta(a,b)
        else:
            print('Não rolou')
            pass

    if check == 5:
        print('Quais nodos deseja separar?')
        a = int(input(''))
        b = int(input(''))
        if(grafo[a,b] and grafo[b,a]) == 1:
            mata_aresta(a,b)
        else:
            print('Não rolou')
            pass

    if check == 6:
        print('Visualização por Matriz')
        print(grafo)
        print('Visualização por Lista')
        for i in range(0,len(grafo)):
            print(i, end='')
            for j in range(0, len(grafo[i])):
                if (int(grafo[i][j]) == 0):
                    pass
                else:
                    print(' -> {}'.format(j), end='')
            print('')

    if check == 7:
        if (np.array_equal(grafo, grafo.transpose())): #Compara a matriz com a sua transposta, sabendo se é direcionada ou não
            print('Não existem fontes em grafos não direcionados')
        else:
            for i in range(0,len(grafo)):
                a = grafo[:,i].tolist()
                for k in range(0, len(a)):
                    a[k] = int(a[k])
                b = np.zeros(len(a), dtype=int).tolist()
                if (a==b):
                    print('{} Fonte'.format(i))

    if check == 8: 
        if (np.array_equal(grafo, grafo.transpose())):
            print('Não existem sumidouros em grafos não direcionados')
        else:
            for i in range(0,len(grafo)):
                a = grafo[i].tolist()
                for k in range(0, len(a)):
                    a[k] = int(a[k])

                b = np.zeros(len(a), dtype=int).tolist()
                if (a==b):
                    print('{} Sumidouro'.format(i))

    if check == 9:
        control = int(input('Qual o vértice? '))
        if(np.array_equal(grafo, grafo.transpose())): #Checa se o grafo é não direcionado
            a = grafo[control].tolist() #O grau de um vértice em um grafo não direcionado é
            contv = 0 #bem mais simples de se encontrar
            for i in range(0, len(a)):
                if a[i] == '0':
                    pass
                else:
                    contv += 1
            print('Vértice {} de Grau {}'.format(control, contv))
        else: #Se o grafo não for direcionado, passa tanto o grau de entrada quanto o de saída
            a = grafo[:,control].tolist()
            b = grafo[control]
            cont_e = 0
            cont_s = 0
            for i in range(0, len(a)):
                if a[i] == '0':
                    pass
                else:
                    cont_e += 1
                if b[i] == '0':
                    pass
                else:
                    cont_s += 1

            print('Vértice {} Grau de Entrada {} e Grau de Saída {}'.format(control, cont_e, cont_s))

    if check == 10:
        control = int(input('Defina o nodo de origem: '))
        busca_bts(control)

    if check == 11:
        control = int(input('Defina o nodo de origem: '))
        busca_dfs(control)
        
    if check == 12:
        control = int(input('Qual nodo será a origem: '))
        alg_prim(control)

    if check == 13:
        print('Árvore Mínima')
        alg_kruskal()

    if check == 14:
        valor = int(input('Qual o nodo de origem?: '))
        alg_dijkstra(valor)