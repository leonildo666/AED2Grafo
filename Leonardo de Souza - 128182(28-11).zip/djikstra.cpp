#include <stdio.h>
#include <iostream>
#include <limits.h>
#define V 9
using namespace std;

int minDistance(int DIST_from_fnodo[], bool CHECK[])
{
    int minD = INT_MAX, min_index,ver;
    for (int ver=0; ver<V; ver++)
    {
        if (!CHECK[ver] && DIST_from_fnodo[ver] <=minD)
        {
            minD = DIST_from_fnodo[ver];
            min_index = ver;
        }
    }
    return min_index;
}

void Dijkstra(int graph[V][V], int F_NODO)
{
    int DIST_from_fnodo[V],i;
    bool CHECK[V];

    for (i=0; i<V; i++)
    {
        DIST_from_fnodo[i] = INT_MAX;
        CHECK[i] = false;
    }
    DIST_from_fnodo[F_NODO] = 0;

    for (i=1; i<V-1; i++)
    {
        int u = minDistance(DIST_from_fnodo, CHECK);
        CHECK[u] = true;
        for (int ver = 0; ver < V; ver++)

            if (!CHECK[ver] && graph[u][ver] && DIST_from_fnodo[u] != INT_MAX && DIST_from_fnodo[u]+graph[u][ver] < DIST_from_fnodo[ver])

                DIST_from_fnodo[ver] = DIST_from_fnodo[u] + graph[u][ver];
    }

    cout << "DISTANCIAS DO FIRST NODO"<< endl;
    for (int i = 0; i < V; i++)
        cout <<i <<" \t\t " <<DIST_from_fnodo[i] <<endl;
}

int main()
{
   int GRAFO[V][V] = {{0,  4, 0,  0,  0,  0, 0,  8, 0},
                      {4,  0, 8,  0,  0,  0, 0, 11, 0},
                      {0,  8, 0,  7,  0,  4, 0,  0, 2},
                      {0,  0, 7,  0,  9, 14, 0,  0, 0},
                      {0,  0, 0,  9,  0, 10, 0,  0, 0},
                      {0,  0, 4,  0, 10,  0, 2,  0, 0},
                      {0,  0, 0, 14,  0,  2, 0,  1, 6},
                      {8, 11, 0,  0,  0,  0, 1,  0, 7},
                      {0,  0, 2,  0,  0,  0, 6,  7, 0}};

    Dijkstra(GRAFO, 0);
    return 0;
}
